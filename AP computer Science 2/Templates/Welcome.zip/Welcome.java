/*
 *Welcome to the MOOC! 
 */

public class Welcome{
  public static void main(String[] args){
  
  
    System.out.println("Welcome to the AP CS MOOC");
  
    System.out.println("Also known as:");
    
    System.out.println("The Advanced Placement Computer Science Massive Open Online Course");
  
  
  }
}