/*
* Lesson 32 Coding Activity 1
* 
* For the Lesson 32 activities, you will be asked to write one or more methods.
* Use the template to write a main method that tests each of your methods, 
* then paste everything into the code runner box. Your submission should 
* begin with the first import statement and end with the final }.
* 
* Write a method that takes a parameter for the number of a month 
* and prints the month's name. 
* 
* This method must be called monthName() and it must have an integer parameter. 
* 
* Calling monthName(8) should print August to the screen.
*/


import java.util.Scanner;

class Lesson_32_Activity_One {
      
         /*fill in the rest of the method declaration monthName()
          {
          //Write your code here
          }
          */
        
        public static void main(String[] args)
         {
         /*
          * Test your method here
          */
         }
}
